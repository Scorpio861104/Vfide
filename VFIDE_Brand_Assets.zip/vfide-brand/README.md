# VFIDE Brand Assets — The Monument Mark

## Etymology

**V** = Veritas (Latin: truth)
**F** = Fides (Latin: trust, faith, loyalty)
**VFIDE** = "In truth and trust"

## The Mark

The monument is a unified VF monogram where the V's two faceted arms are joined
at the top by the F's two horizontal bars (capstone bar + crossbar). Serif
brackets at each arm's origin give it architectural weight. The vertex terminates
in a luminous focal point — the moment truth and trust converge into proof.

### Anatomy

- **Arms**: Two angled slabs with distinct left/right lighting (dimensional depth)
- **Capstone bar**: The F's top horizontal — full luminosity, bridges the arms
- **Crossbar**: The F's mid horizontal — dimmer, secondary reading
- **Serif brackets**: Architectural caps where the arms meet the capstone
- **Corner marks**: Precision notation (measurement, calibration)
- **Tick marks**: Subtle graduations along the capstone — trust is measured
- **Vertex chevron**: The base narrows to a pointed termination
- **Focal point**: Three concentric rings of diminishing opacity — the proof
- **Light axis**: A ghosted vertical from base to top — truth rising
- **Construction lines**: Faint diagonals — the geometry is intentional

### Inscription

VERITAS · FIDES appears below the mark in serif, letter-spaced, quiet.
Use only beneath the primary mark or within the coin seal variant.

## Files

```
mark/
  vfide-mark-primary.svg     400×440  Full mark with VERITAS · FIDES inscription
  vfide-mark-clean.svg       400×400  Mark only, no inscription (most versatile)

favicon/
  icon.svg                    32×32   Simplified for browser tab
  apple-touch-icon.svg       180×180  iOS home screen (dark background)

social/
  og-image.svg              1200×630  Open Graph / social share card

lockup/
  vfide-lockup-horizontal.svg 480×120 Mark + VFIDE wordmark + motto
```

## Color Values

| Token       | Hex       | Usage                        |
|-------------|-----------|------------------------------|
| Truth cyan  | #00e8f0   | Bars, focal point, accents   |
| Truth dim   | #0090a8   | Secondary elements           |
| Arm dark    | #0a1218   | Left arm deep shadow         |
| Arm mid-L   | #1c3040   | Left arm highlight           |
| Arm mid-R   | #243848   | Right arm highlight          |
| Arm dark-R  | #0e1a22   | Right arm deep shadow        |
| Background  | #08080E   | Canonical dark background    |
| Inscription | #3a3a4c   | VERITAS · FIDES text         |

## Usage Rules

1. **Minimum size**: The mark should never render smaller than 24px wide.
   Below that, use the favicon variant which has simplified geometry.

2. **Clear space**: Maintain padding equal to the height of the capstone bar
   on all sides of the mark.

3. **Background**: Designed for dark backgrounds (#08080E to #12121A range).
   On lighter backgrounds, increase arm fill brightness proportionally.

4. **Never rotate, stretch, recolor the bars, or add effects**.
   The mark is precisely calibrated.

5. **Favicon (icon.svg)** replaces the existing /public/icon.svg.
   **Apple touch icon** replaces /public/apple-touch-icon.svg.
   **OG image** replaces /public/og-image.svg.

## Drop-in Replacement

To update the existing codebase:

```bash
cp favicon/icon.svg            ../public/icon.svg
cp favicon/apple-touch-icon.svg ../public/apple-touch-icon.svg
cp social/og-image.svg          ../public/og-image.svg
```

The manifest.json, layout.tsx metadata, and next.config.ts reference these
same filenames — no code changes needed beyond the file swap.
