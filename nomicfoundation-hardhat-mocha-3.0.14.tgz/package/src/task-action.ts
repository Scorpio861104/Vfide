import type { HardhatConfig } from "hardhat/types/config";
import type { NewTaskActionFunction } from "hardhat/types/tasks";
import type { TestRunResult } from "hardhat/types/test";
import type { Result } from "hardhat/types/utils";
import type { MochaOptions } from "mocha";

import { resolve as pathResolve } from "node:path";

import { HardhatError } from "@nomicfoundation/hardhat-errors";
import { setGlobalOptionsAsEnvVariables } from "@nomicfoundation/hardhat-utils/env";
import { getAllFilesMatching } from "@nomicfoundation/hardhat-utils/fs";
import debug from "debug";
import { errorResult, successfulResult } from "hardhat/utils/result";

import { createPerformanceTracker } from "./performance.js";

interface TestActionArguments {
  testFiles: string[];
  bail: boolean;
  grep?: string;
  noCompile: boolean;
}

type PerformancePhase =
  | "Build"
  | "Get test files"
  | "Mocha setup"
  | "Test file loading"
  | "Test execution"
  | "Reporting";

const performanceScope = "hardhat:mocha:performance";
const performanceLog = debug(performanceScope);
const perf = createPerformanceTracker<PerformancePhase>(
  performanceScope,
  "Mocha test task",
);

function isTypescriptFile(path: string): boolean {
  return /\.(ts|cts|mts)$/i.test(path);
}

function isJavascriptFile(path: string): boolean {
  return /\.(js|cjs|mjs)$/i.test(path);
}

async function getTestFiles(
  testFiles: string[],
  config: HardhatConfig,
): Promise<string[]> {
  if (testFiles.length !== 0) {
    const testFilesAbsolutePaths = testFiles.map((x) =>
      pathResolve(process.cwd(), x),
    );

    return testFilesAbsolutePaths;
  }

  return getAllFilesMatching(
    config.paths.tests.mocha,
    (f) => isJavascriptFile(f) || isTypescriptFile(f),
  );
}

let testsAlreadyRun = false;
const testWithHardhat: NewTaskActionFunction<TestActionArguments> = async (
  { testFiles, bail, grep, noCompile },
  hre,
): Promise<Result<TestRunResult, TestRunResult>> => {
  // Set an environment variable that plugins can use to detect when a process is running tests
  process.env.HH_TEST = "true";

  // Sets the NODE_ENV environment variable to "test" so the code can detect that tests are running
  // This is done by other JS/TS test frameworks like vitest
  process.env.NODE_ENV ??= "test";

  perf.start();

  setGlobalOptionsAsEnvVariables(hre.globalOptions);

  perf.startPhase("Build");

  if (!noCompile) {
    await hre.tasks.getTask("build").run({
      noTests: true,
    });
    console.log();
  }

  perf.endPhase("Build");
  perf.startPhase("Get test files");

  const files = await getTestFiles(testFiles, hre.config);

  perf.endPhase("Get test files");

  if (files.length === 0) {
    return successfulResult({
      summary: {
        failed: 0,
        passed: 0,
        skipped: 0,
        todo: 0,
      },
    });
  }

  const unhandledRejectionHookPath = "./unhandled-rejection-mocha-hook.js";

  perf.startPhase("Mocha setup");

  if (hre.config.test.mocha.parallel === true) {
    const imports = [];

    const tsx = new URL(import.meta.resolve("tsx/esm"));
    const unhandledRejectionHook = new URL(
      import.meta.resolve(unhandledRejectionHookPath),
    );
    imports.push(tsx.href);

    hre.config.test.mocha.require = hre.config.test.mocha.require ?? [];
    hre.config.test.mocha.require.push(unhandledRejectionHook.href);

    if (
      hre.globalOptions.coverage === true ||
      hre.globalOptions.gasStats === true ||
      hre.globalOptions.gasStatsJson !== undefined
    ) {
      const testWorkerDone = new URL(
        import.meta.resolve("@nomicfoundation/hardhat-mocha/test-worker-done"),
      );

      hre.config.test.mocha.require.push(testWorkerDone.href);
    }

    process.env.NODE_OPTIONS = imports
      .map((href) => `--import "${href}"`)
      .join(" ");
  } else {
    // Import the handler directly when not running in parallel mode
    await import(unhandledRejectionHookPath);
  }

  const { default: Mocha } = await import("mocha");

  const mochaConfig: MochaOptions = { ...hre.config.test.mocha };

  if (grep !== undefined && grep !== "") {
    mochaConfig.grep = grep;
  }

  if (bail) {
    mochaConfig.bail = true;
  }

  const mocha = new Mocha(mochaConfig);

  files.forEach((file) => mocha.addFile(file));

  perf.endPhase("Mocha setup");

  // Because of the way the ESM cache works, loadFilesAsync doesn't work
  // correctly if used twice within the same process, so we throw an error
  // in that case
  if (testsAlreadyRun) {
    throw new HardhatError(
      HardhatError.ERRORS.HARDHAT_MOCHA.GENERAL.TEST_TASK_ESM_TESTS_RUN_TWICE,
    );
  }
  testsAlreadyRun = true;

  // We write instead of console.log because Mocha already prints some newlines
  process.stdout.write("Running Mocha tests\n");

  perf.startPhase("Test file loading");

  // This instructs Mocha to use the more verbose file loading infrastructure
  // which supports both ESM and CJS
  await mocha.loadFilesAsync();

  perf.endPhase("Test file loading");
  perf.startPhase("Test execution");

  await hre.hooks.runHandlerChain(
    "test",
    "onTestRunStart",
    ["mocha"],
    async () => {},
  );

  let total = 0;
  const testFailures = await new Promise<number>((resolve) => {
    const runner = mocha.run(resolve);
    total = runner.total;
  });

  perf.endPhase("Test execution");
  perf.startPhase("Reporting");

  if (hre.config.test.mocha.parallel !== true) {
    await hre.hooks.runHandlerChain(
      "test",
      "onTestWorkerDone",
      ["mocha"],
      async () => {},
    );
  }
  await hre.hooks.runHandlerChain(
    "test",
    "onTestRunDone",
    ["mocha"],
    async () => {},
  );

  perf.endPhase("Reporting");

  console.log();

  perf.end();

  perf.logInto(performanceLog);
  perf.clear();

  const result: TestRunResult = {
    summary: {
      failed: testFailures,
      passed: total - testFailures,
      skipped: 0,
      todo: 0,
    },
  };

  return testFailures > 0 ? errorResult(result) : successfulResult(result);
};

export default testWithHardhat;
